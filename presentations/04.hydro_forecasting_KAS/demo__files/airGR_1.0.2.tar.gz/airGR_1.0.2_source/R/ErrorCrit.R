ErrorCrit <- function(InputsCrit,OutputsModel,FUN_CRIT, verbose = TRUE){
    return( FUN_CRIT(InputsCrit,OutputsModel, verbose = verbose) )
}

