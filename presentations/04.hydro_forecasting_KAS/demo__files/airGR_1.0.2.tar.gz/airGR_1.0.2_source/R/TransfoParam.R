TransfoParam <- function(ParamIn,Direction,FUN_TRANSFO){
    return( FUN_TRANSFO(ParamIn,Direction) )
}

